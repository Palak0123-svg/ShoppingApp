export const Prices =[
    
    {
        _id:0,
        name:"$0 to 19",//diplay
        array:[0,19]// behind the sceen isme se check hoga
    },
    {
        _id:1,
        name:"$20 to 39",//diplay
        array:[20,39]// behind the sceen isme se check hoga
    },
    {
        _id:2,
        name:"$40 to 59",//diplay
        array:[40,59]// behind the sceen isme se check hoga
    },
    {
        _id:3,
        name:"$60 to 79",//diplay
        array:[60,79]// behind the sceen isme se check hoga
    },
    {
        _id:4,
        name:"$80 to 99",//diplay
        array:[80,99]// behind the sceen isme se check hoga
    },
    {
        _id:5,
        name:"$100 to more",//diplay
        array:[100,9999]// behind the sceen isme se check hoga
    },
]